

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.break', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container pt-5">
        <a href="/beranda" class="btn btn-primary">Kembali</a>
        <div class="row g-0 pt">
            <div class="col-md-8 border-right">

                <!-- menu kanan -->
                <div class="row">
                    <div class="col-md-10" style="word-wrap: break-word;  ">
                        <div class="feed-dass">
                            <?php $__currentLoopData = $DesaList->wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $das): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h3><?php echo e($loop->iteration); ?>. Wisata <?php echo e($das->nama); ?></h3>

                                <img src="<?php echo e(asset('daerah/' . $das->gambar)); ?>" style="height: auto; width: 100%;"
                                    alt="">

                                <br><br>
                                <p style="text-align: justify;"><?php echo e($das->deskripsi); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>


            </div>

            <!-- menu kanan -->
            <div class="col-md-4 px-3">
                <div class="menu-kanan" style="position: sticky; top: 20px;">
                    <div class="kalender border-bottom">
                        <iframe
                            src="https://calendar.google.com/calendar/embed?src=adiaksa%40undiksha.ac.id&ctz=Asia%2FMakassar"
                            style="border: 0" width="100%" height="260" frameborder="0" scrolling="no"></iframe>
                    </div>
                    <div class="map mt-2 border-bottom">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1010295.996606638!2d114.51106531102594!3d-8.453713789473323!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd141d3e8100fa1%3A0x24910fb14b24e690!2sBali!5e0!3m2!1sen!2sid!4v1639068139544!5m2!1sen!2sid"
                            width="100%" height="160" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



</div>



<!-- js -->


</div>
</div>
</div>

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js"
    integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous">
</script>
<script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js"
    integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous">
</script>


</body>

</html> --}}

<?php echo $__env->make('layouts.user.user-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\belajar-laravel\secret-land-rev\resources\views/beranda/beranda-detail.blade.php ENDPATH**/ ?>