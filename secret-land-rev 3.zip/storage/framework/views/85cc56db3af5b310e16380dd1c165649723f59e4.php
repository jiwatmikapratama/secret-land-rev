

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <main class="form-signin">
            <?php if(session()->has('sukses')): ?>
                <div class="alert alert-succes alert-dismissible fade show" role="alert">
                    <?php echo e(session('sukses')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(session()->has('loginError')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('loginError')); ?>


                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <form method="POST" action="/login">
                <?php echo csrf_field(); ?>
                <div class="row justify-content-center">
                    <div class="col-sm-7">
                        <img class="mb-1" src="/img/logo.png" alt="" width="150">
                    </div>
                </div>
                <h1 class="h4 mb-3 fw-normal text-center">Get your Nice spot Village</h1>
                <br>
                <h1 class="h6 sm-6 fw-normal text-center">Login</h1>

                <div class="form-floating">
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                    <label for="username"><?php echo e(__('E-Mail Address')); ?></label>
                </div>
                <div class="form-floating">
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <label for="floatingPassword"><?php echo e(__('Password')); ?></label>
                </div>
                <small class="d-block text-end mt-6">
                    <?php if(Route::has('password.request')): ?>
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?>

                        </a>
                    <?php endif; ?>
                </small>
                <div class="checkbox mb-1">
                    <br>
                    <label>
                        <input class="form-check-input" type="checkbox" name="remember" id="remember"
                            <?php echo e(old('remember') ? 'checked' : ''); ?>><?php echo e(__('Remember Me')); ?>

                    </label>
                </div>
                <button id="btn" class="w-100 btn btn-lg btn-primary login" type="submit"><a href="/beranda"></a>
                    <?php echo e(__('Login')); ?></button>
            </form>
            <small class="d-block text-start mt-6">Belum punya akun ? <a href="/register">Register</a></small>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login.login-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\belajar-laravel\secret-land-rev\resources\views/login/index.blade.php ENDPATH**/ ?>