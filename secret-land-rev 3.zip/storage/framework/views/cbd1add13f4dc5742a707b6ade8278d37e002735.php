

<?php $__env->startSection('content'); ?>
    
    <header class="flex">
        <div class="container"><br><br><br>
            <div class="header-title">
                <h1>Cari Suasana Baru</h1>
                <p>Kami menawarkan solusi yang menjembatani Instansi daerah lebih tepatnya desa yang ingin
                    mengembangkan atau mempublikasikan desanya agar dikenal luas seNusantara maupun Internasional.</p>
            </div>
            <div class="header-form2">
                <h2>Pilih Daerah & Destinasi Wisata</h2>
                <form action="/beranda-search" method="GET">
                    <input type="search" name="search" class="form-control2" placeholder="search">
                    <button class="btn btn-outline-light" type="submit"><i class="fa fa-search"></i></button>
                </form>
                <form action="">

                    
                </form>
                <div class="container mt-4 mb-4 p-3 d-flex justify-content-center">

                    <div class="row" data-aos="fade-up">
                        <?php $__currentLoopData = $KategoriList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col">
                                <button class="btn tombol"><a href="" ><?php echo e($kategori->nama); ?></a></button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="col">

                        </div>
                        <div class="col">

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </header>
    <div class="gg">
        <div class="container" data-aos="fade-up">

            
            <div class="section-title">
                <h2>REKOMENDASI WISATA</h2>
                <p>Wisata yang cocok untuk anda kunjungi</p>
                <hr>
                <div class="row d" data-aos="fade-up">
                    <?php $__currentLoopData = $WisataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wisata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <a href="beranda-detail/<?php echo e($wisata->id); ?>">
                                <div class="card2">
                                    <img src="<?php echo e(asset('wisata/' . $wisata->gambar[0])); ?>" class="card-image2" alt="...">
                                    <div class="card-body2">
                                        <h5 class="card-titlet" style="font-weight:bold;"> <?php echo e($wisata->nama); ?></h5>
                                        <h5 style="font-size:15px;"><?php echo e($wisata->desa->nama); ?></h5>
                                        
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

                <div class="col-md-3 pull-right mt-3" style="">
                    <?php echo e($WisataList->links()); ?>

                </div>
            </div>

            <?php echo $__env->make('partials.break', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <div class="section-title">
                <h2>REKOMENDASI DESA</h2>
                <p>Desa yang cocok untuk anda kunjungi</p>
                <hr>
                <div class="row d" data-aos="fade-up">
                    <?php $__currentLoopData = $DesaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($desa->status == 'approve'): ?>
                            <div class="col">
                                <a href="beranda-detail/<?php echo e($desa->id); ?>">
                                    <div class="card2">
                                        <img src="<?php echo e(asset('daerah/' . $desa->gambar)); ?>" class="card-image2"
                                            alt="...">
                                        <div class="card-body2">
                                            <h5 class="card-titlet" style="font-weight:bold;"> <?php echo e($desa->nama); ?></h5>
                                            <h5 style="font-size:15px;"><?php echo e($desa->kabupaten->nama); ?></h5>
                                            
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-3 pull-right mt-3" style="">
                    <?php echo e($DesaList->links()); ?>

                </div>
            </div>



            <br><br><br><br>
            

            
            <!-- ======= Bagian Contact ======= -->
            <section id="contact" class="contact mb-5 ">

                <div class="section-title">
                    <h2>KONTAK</h2>
                    <p>Jika ingin menghubungi saya silakan melihat data saya dibawah ini!</p>
                    <hr>
                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="100">
                    <div class="g col-lg-6">
                        <div class="info-box mb-4">
                            <i class="uil uil-location-point icon"></i>
                            <h3>Alamat Saya</h3>
                            <p>Bondalem, Kec. Tejakula, Kabupaten Buleleng, Bali</p>
                        </div>
                    </div>

                    <div class="g col-lg-3 col-md-6">
                        <div class="info-box  mb-4">
                            <i class="uil uil-envelopes icon"></i>
                            <h3>Email saya</h3>
                            <p>programerbiasa@gmail.com</p>
                        </div>
                    </div>

                    <div class="g col-lg-3 col-md-6">
                        <div class="info-box  mb-4">
                            <i class="uil uil-phone-volume icon"></i>
                            <h3>Nomor saya</h3>
                            <p>+62 8191 6601 444</p>
                        </div>
                    </div>

                </div>

                <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="100">
                    <div class="col-md-5 mt-5">
                        <a href="/daftar-wisata" class="button rounded-pill shadow tebel-sedang">DAFTAR WISATA YANG
                            BELUM
                            ADA</a>
                    </div>
                    <div class="col-md-5 mt-5">
                        <a href="/daftar-desa" class="button rounded-pill shadow tebel-sedang">DAFTAR DESA YANG
                            BELUM
                            ADA</a>
                    </div>
                </div>
        </div>
        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="100">

            

            
            

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.user-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\belajar-laravel\secret-land-rev\resources\views/beranda/index.blade.php ENDPATH**/ ?>