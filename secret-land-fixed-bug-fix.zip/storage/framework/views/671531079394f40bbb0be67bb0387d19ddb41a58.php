

<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <br>
    <div class="container-fluid">
        <div class="row">
            <?php echo $__env->make('partials.admin.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h2>Data Desa</h2>

                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php elseif(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php else: ?>
                <?php endif; ?>

                <table class="table">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama Desa</th>
                            <th scope="col">Gambar</th>
                            <th scope="col">Daerah</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $__currentLoopData = $DesaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->nama); ?></td>
                                <td>
                                    <img src="<?php echo e(asset('daerah/' . $data->gambar)); ?>"
                                        style="max-height: 50px; max-width: 50px;" alt="">
                                </td>
                                <td><?php echo e($data->kabupaten->nama); ?></td>
                                <td >
                                    <div style="max-height: 120px; max-width: 600px; overflow:hidden; white-space: normal;"><?php echo e($data->deskripsi); ?></div></td>
                                <td >
                                    <div style="max-height: 120px; max-width: 300px; overflow:hidden; white-space: normal;"><?php echo e($data->address); ?></div></td>
                                <td>
                                    <div class="badge <?php echo e($data->status == 'pending' ? 'bg-warning' : 'bg-success'); ?> "
                                        style="color: <?php echo e($data->status == 'pending' ? 'black' : 'white'); ?> ;"><?php echo e($data->status); ?></div>

                                </td>
                                <td>
                                    <a class="btn btn-success" href="/dashboard/desa/approve/<?php echo e($data->id); ?>"
                                        onclick="return confirm('Anda yakin ingin menyetujui?');">approve</a>
                                    <a class="btn btn-warning" href="/dashboard/desa-edit/<?php echo e($data->id); ?>">edit</a>
                                    <a class="btn btn-danger" href="/dashboard/desa/<?php echo e($data->id); ?>"
                                        onclick="return confirm('Anda yakin ingin menghapus?');">delete</a>
                                </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <hr>
                <div
                    class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h2>Data Wisata</h2>
                </div>



                <table class="table">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama Wisata</th>
                            <th scope="col">Gambar</th>
                            <th scope="col">Desa</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Alamat</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php $__currentLoopData = $WisataList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td>
                                    
                                    
                                    <?php $__currentLoopData = json_decode($item->gambar); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('/wisata/' . $image)); ?>"
                                            style="max-height: 50px; max-width: 50px;" alt="multiple image"
                                            class="w-20 h-20 border border-blue-600">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    

                                </td>
                                <td><?php echo e($item->desa->nama); ?></td>
                                <td >
                                    <div style="max-height: 120px; max-width: 600px; overflow:hidden; white-space: normal;"><?php echo e($item->deskripsi); ?></div></td>
                                <td >
                                   <div style="max-height: 120px; max-width: 300px; overflow:hidden; white-space: normal;"> <?php echo e($item->address); ?></div></td>
                                <td>
                                    <div class="badge <?php echo e($item->status == 'pending' ? 'bg-warning' : 'bg-success'); ?> "
                                        style="color: <?php echo e($item->status == 'pending' ? 'black' : 'white'); ?> ;"><?php echo e($item->status); ?></div>

                                </td>
                                <td>
                                    <a class="btn btn-success" href="/dashboard/wisata/approve/<?php echo e($item->id); ?>"
                                        onclick="return confirm('Anda yakin ingin menyetujui?');">approve</a>
                                    <a class="btn btn-warning" href="/dashboard/wisata-edit/<?php echo e($item->id); ?>">edit</a>
                                    <a class="btn btn-danger" href="/dashboard/wisata/<?php echo e($item->id); ?>"
                                        onclick="return confirm('Anda yakin ingin menghapus?');">delete</a>
                                </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admin-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\belajar-laravel\secret-land-fixed\resources\views/admin/index.blade.php ENDPATH**/ ?>