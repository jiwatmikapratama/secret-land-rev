<footer id="footer" class="text-center">
    <small>Copyright &copy; 2021 - Limit D. Ocean Corporate. All Right Reserved.</small>
</footer>
<?php /**PATH D:\Project\belajar-laravel\secret-land-rev\resources\views/partials/footer.blade.php ENDPATH**/ ?>