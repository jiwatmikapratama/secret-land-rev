

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.break', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container pt-5">
        <div class="row g-0 pt">
            <div class="col-md-8 border-right">

                <!-- menu kanan -->
                <div class="row">
                    <div class="col-md-10" style="word-wrap: break-word;  ">
                        <div class="feed-dass">
                            <?php $__currentLoopData = $DesaList->wisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $das): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h3><?php echo e($loop->iteration); ?>. Wisata <?php echo e($das->nama); ?></h3>

                                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-inner">
                                        <?php $__currentLoopData = json_decode($das->gambar); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                                                <img class="d-block w-100" src="<?php echo e(asset('/wisata/' . $image)); ?>"
                                                    style="max-height: 2000px; max-width: ;" alt="multiple image"
                                                    class="w-20 h-20 border border-blue-600">
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button"
                                        data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#carouselExampleControls" role="button"
                                        data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                                <p style="text-align: justify;"><?php echo e($das->deskripsi); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-md-4 px-3">
                <iframe src="<?php echo e($DesaList->address); ?>" width="100%" height="160" style="border:0;" allowfullscreen=""
                    loading="lazy" referrerpolicy="no-referrer-when-downgrade" frameborder="0"></iframe>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



</div>



<!-- js -->


</div>
</div>
</div>

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js"
    integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous">
</script>
<script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js"
    integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous">
</script>


</body>

</html> --}}

<?php echo $__env->make('layouts.user.user-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\belajar-laravel\secret-land-rev\resources\views/beranda/beranda-detail.blade.php ENDPATH**/ ?>