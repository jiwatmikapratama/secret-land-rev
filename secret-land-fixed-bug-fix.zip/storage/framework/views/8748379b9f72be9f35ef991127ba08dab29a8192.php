<footer id="footer" class="text-center">
    <small>Copyright &copy; 2021 - Adiaksa CEO of Limit D. Ocean Corporate. All Right Reserved.</small>
</footer>
<?php /**PATH C:\Users\User\Downloads\cuan\dub\since 4\secret-land-rev 5\resources\views/partials/footer.blade.php ENDPATH**/ ?>